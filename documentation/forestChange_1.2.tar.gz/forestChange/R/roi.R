roi <- structure(function #Region of interest
### This function can retrieve and format GWS and GFC using polygon
### geometries (i.e., GADM).
                       ##details<< The \code{GADM} are imported using
                       ##the in-package \code{\link{getGADM}}.
                       ##Links to the data sets are obtained using
                       ##the in-package
                       ##\code{\link{GFCurls}}. Geographic extents
                       ##in both the \code{GADM} and the \code{GFC}
                       ##are intersected implementing
                       ##\code{\link{HansenUrltoExtent}}. Common
                       ##areas between \code{GFC} and \code{GADM}
                       ##are cropped using two functions of the
                       ##\code{\link{raster}} package:
                       ##\code{\link{crop}} and
                       ##\code{\link{rasterize}}. Depending on
                       ##localization of the \code{GADM} unit,
                       ##several \code{GFC} layers by data type
                       ##might be required. This is done
                       ##implementing the in-package
                       ##\code{\link{FCMosaic}}. This function
                       ##could be memory demanding if the extents
                       ##of the polygons used to cut the \code{GFC}
                       ##are big (30,000 km^2). For these cases,
                       ##machines with RAM of 8 GB or greater should
                       ##be used. In unix-alike systems, the
                       ##package implements parallel execution,
                       ##see \code{\link{parallel}} package.
                       ##references<< Hansen, M. C., Potapov,
                       ##P. V., Moore, R., Hancher, M., Turubanova,
                       ##S. A. A., Tyukavina, A., ... & Kommareddy,
                       ##A. (2013). High-resolution global maps of
                       ##21st-century forest cover change. science,
                       ##342(6160), 850-853.
(
    pol = NULL, ##<<\code{SpatialPolygonsDataFrame}, or
                ##\code{character}. Polygon geometry, the name of a
                ##\code{GADM}, or such a name plus its corresponding
                ##higher-level unit. If \code{NULL} then a list of
                ##\code{GADM} units is printed, see
                ##\code{\link{getGADM}}.
    lyrs = c('treecover2000','lossyear'), ##<<\code{character}. Vector
                                          ##of strings matching layer
                                          ##names in the \code{GFC}.
                                          ##Defaults
                                          ##\code{'treecover2000'} and
                                          ##\code{'lossyear'}.
    path, ##<<\code{character}.Location of a directory with the
          ##\code{GFC}. This argument overrides the action of \code{url}.
    utm = TRUE, ##<<\code{logical}. Project to UTM crs.
    mc.cores = detectCores(), ##<<\code{numeric}. The number of cores,
                              ##see \code{\link{mclapply}}.
    ... ##<<Additional arguments in \code{\link{getGADM}}.
) {
    pol. <- pol
    if(inherits(pol, getOption('inh')[3:4])){
        pol <- getGADM(pol,...)# <-
        if(is.null(pol.))
            return(pol)}
    fils <- paste(lyrs, collapse = '|')
    fprll <- getOption('fapp')
    if(missing(path)){
        urt. <- layers2url(pol, lyrs)
        td <- tempdir()
        fl <- file.path(td, basename(urt.))
        isUnix <- !getOption('isWin')
        if(isUnix)
            marg[['mc.cores']] <- mc.cores
        marg. <- c(list(FUN = function(x,y, mode = 'wb')
            download.file(x,y, mode = 'wb'),
            x = urt.,
            y = fl), marg)
        if(!all(basename(urt.)%in%dir(td))){
            outp <- do.call(fprll, marg.)}
    }
    if(!missing(path)){
        fils <- paste(lyrs, collapse = '|')
        drp <- dir(path)
        grpath <- drp[grepl(fils,drp)]
        fl <- file.path(path, grpath)
        right <- sapply(lyrs, function(x)grep(x, fl))
        fl <- fl[right]
    }
    rst <- lapply(fl,function(x)raster(x))
    difext <- extent(rst[[1L]]) != extent(pol)
     if(difext){
        marg. <- c(list(FUN = function(x,y)
            cropRaster(x,y),
            x = rst,
            MoreArgs = list(y = pol)), marg)
        print('Cutting layers ...')
        rst. <- do.call(fprll, marg.)
        names(rst.) <- lapply(rst., function(x)
            names(x))
        needBind <- !length(rst) == length(lyrs)
        if(!needBind)
            rst <- ordLayers(rst., lyrs)
        if(needBind){
            print('Binding layers ...')
            ## rst <- bindLayers(rst., lyrs, pol)}
            rst <- bindLayers(rst., lyrs, pol)}}
    rst <- cropRaster(rst, pol)
    if(utm){
        print('Projecting layers ...')
        rst <- lonlat2utm(rst)}
    ## names(rst) <- lyrs
    return(rst)
### \code{RasterStack}, or set of \code{GADM} units.
} , ex=function() {
    ## A list of departments of Colombia is printed:
    ## \donttest{
    ## dep <- FCPolygon(level = 1)
    ## head(dep)
    ## }
    ## Two adjacent layers of GFC must be bounded together before cropping
    ## the GFC data using the boundaries of the the municipality of
    ## 'Cumaribo' in Colombia. This is automatically developed by
    ## FCPolygon:
    ## \donttest{
    ## cumariboArea <- FCPolygon(pol = 'Cumaribo', mc.cores = 2)
    ## }
    ## The name 'Mosquera' matchs two municipalities of Colombia. A
    ## corresponding department should be specified in the argument 'pol'
    ## of FCPolygon:
    ## \donttest{
    ## mosquera <- FCPolygon('Mosquera')
    ## mosqueraNarinho <- FCPolygon(pol = c('Mosquera','Narino'), mc.cores = 2)
    ## }
})
